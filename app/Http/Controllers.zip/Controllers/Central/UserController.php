<?php

namespace App\Http\Controllers\Central;

use App\Http\Requests\UpdateUserRequest;
use App\Models\User;

class UserController extends Controller
{
   
    public function index()
    {
        return view('central.users.index');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        return view('users.edit', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserRequest $request, User $user)
    {
        $user->update($request->validated());

        return redirect()->route('users.index')->with('success', 'User updated successfully');
    }
}
