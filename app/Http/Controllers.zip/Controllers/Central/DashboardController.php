<?php

namespace App\Http\Controllers\Central;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller; 

class DashboardController extends Controller
{
    public function __invoke()
    {
        // return view('pages.central.dashboard');
        return view('central.dashboard');
    }
}
